ST Tag Programmer
--------------------


Version 1.0.0.0 | 8-March-2015

- Pre-release
- Supports: UHF RFID Tag (860-960mhz)




SYSTEM REQUIREMENTS
--------------------

- ST Tag Programmer device
- Computer with Windows XP or higher




INSTALLATION
--------------------

1. Unpack ZIP file to any location on your hard drive.

2. Install ST Tag Programmer device drivers from the "Drivers"
   subfolder run CP210xVCPInstaller.exe.

3. Plug in the ST Tag Programmer device into one of your USB ports.
   Make sure Windows assigns a COM port number between 1-9 in
   the Windows device manager.

4. Run TagProgrammer.exe.




USAGE
--------------------

- In Read Tag(s) tab, click Read button to start reading
  the UHF RFID Tag or Timing Chip.

- To Read TID, check the TID checkbox and set the start 
  address/length.

- In Write Tag(s) tab, enter Bib Number to program the 
  UHF RFID Tag or Timing Chip and click Write button.

- To increment Bib Number, check the Auto increment checkbox.

- To write automatically, check the Auto write checkbox.

- To adjust write speed, select in Write interval dropdown box.

- To clear list both in Read Tag(s) and Write Tag(s) tab,
  right click inside the list and click Clear.