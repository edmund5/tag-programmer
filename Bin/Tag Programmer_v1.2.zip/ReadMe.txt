Tag Programmer
--------------------

Version 1.0.2.0 | 22-May-2015

- Added: Wait Dialog on Connect
- New App Icon
- Bug fixes

Version 1.0.1.0 | 12-March-2015

- Small bug fixes

Version 1.0.0.0 | 8-March-2015

- Pre-release
- Supports: UHF RFID Tag (860-960mhz)




SYSTEM REQUIREMENTS
--------------------

- Tag Programmer device
- Computer with Windows XP or higher




INSTALLATION
--------------------

1. Unpack ZIP file to any location on your hard drive.

2. Install Tag Programmer device drivers from the "Drivers"
   subfolder run CP210xVCPInstaller.exe.

3. Install BEBAS__.TTF & Titillium-Regular.otf font from the "Install Fonts"
   subfolder.

4. Plug in the Tag Programmer device into one of your USB ports.
   Make sure Windows assigns a COM port number between 1-9 in
   the Windows device manager.

5. Run TagProgrammer.exe.




USAGE
--------------------

- In Check Tag(s) tab, click Read button to start reading
  the UHF RFID Tag or Timing Chip.

- To Read TID, check the TID checkbox and set the start 
  address/length.

- In Program Tag(s) tab, enter bib number to program the 
  UHF RFID Tag or Timing Chip and click Write button.

- To increment bib number, check the Auto increment checkbox.

- To automatically program tag, check the Auto write checkbox.

- To adjust write speed, select in Write interval dropdown box.

- To clear list both in Check Tag(s) and Program Tag(s) tab,
  right click inside the list and click Clear.